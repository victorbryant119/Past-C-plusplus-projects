// Wenchen Shi UID: 505453951
// Project 2
// These are the data validation rules I want your program to enforce:
// the first letter of the month must be capitalized
// the day must be between 1 and 31
// the year must be between 1 and 3000
// Your program must gather the month, day and year, in that specific order. However, if you detect an error in an item, you do not have to request or get the remaining items if you don't want to; just be sure you write to cout the required error message and nothing more after that. If instead you choose to gather all input first before checking for any errors, and you detect more than one error, then write only the error message for the first erroneous input item as the last example shows.
#include <iostream>
#include <string>

using namespace std;

int main() {
    int MonthCode = 0;
    string Month;
    int CenturyCode = 0;
    int CenturyValue = 0;
    int YearCode = 0;
    int Year = 0;
    int DayCode = 0;
    int Day = 0;
    cout << "Provide a month: ";
    getline (cin, Month);
  //  Diag
    // cout << Month << endl;
    
    // TODO: DELETE
    /*
    cout << "Provide a day: ";
    cin >> Day;
    cout << "Provide a year: ";
    cin >> Year;
     */
     
   // if (Year % 4 == 0 && Year % 100 != 0){
    // MonthCode = MonthCode - 1;
    // } (tricky: will not work)
    if (Month == "January" || Month == "October"){
        MonthCode = 1;
    }
    else if (Month == "February" || Month == "March" || Month == "November"){
        MonthCode = 4;
    }
    else if (Month == "April" || Month == "July"){
        MonthCode = 0;
    }
    else if (Month == "May"){
        MonthCode = 2;
    }
    else if (Month == "June") {
        MonthCode = 5;
    }
    else if (Month == "August") {
        MonthCode = 3;
    }
    else if (Month == "September" || Month == "December") {
        MonthCode = 6;
    }
    else {
        cout << "Invalid month!" << endl;
        return (-1);
    }
    // cout << "Debug Here " << endl;
    
    cout << "Provide a day: ";
    cin >> Day;
    // Check if Day is valid
    if (Day < 1 || Day > 31) {
        cout << "Invalid day!" << endl;
        return (-1);
    }
    cout << "Provide a year: ";
    cin >> Year;
    // Check if Year is valid
    if (Year < 1 || Year > 3000){
        cout << "Invalid year!" <<endl;
        return (-1);
    }
    //Leap year
    if ((Month == "January" || Month == "February") && (Year % 4 == 0 && Year % 100 != 0)){
        MonthCode = MonthCode - 1;
    }
    else if ((Month == "January" || Month == "February") && (Year % 400 == 0)){
        MonthCode = MonthCode - 1;
    }
        CenturyValue = (Year / 100) % 4;
    if (CenturyValue == 0){
        CenturyCode = -2;
    }
    else if (CenturyValue == 1){
        CenturyCode = 3;
    }
    else if (CenturyValue == 2){
        CenturyCode = 1;
    }
    else if (CenturyValue == 3){
        CenturyCode = -1;
    }
   // Year Code = the year value entered by the user modulo 100 divided by 4 plus the year value entered by the user modulo 100. (Again, the division specified here should be int division)
    // the Year Code value is (2021 % 100) / 4 + (2021 % 100) = (21 / 4) + 21 = 5 + 21 = 26
        YearCode = (Year % 100) / 4 + (Year % 100);
        DayCode = (CenturyCode + Day + YearCode + MonthCode ) % 7;
    //Debugging
       // cout << "DayCode: " << DayCode << endl;
       // cout << "CenturyCode: " << CenturyCode << endl;
       // cout << "Day: " << Day << endl;
       // cout << " YearCode: " << YearCode << endl;
       // cout << "MonthCode: " << MonthCode << endl;
    // Printing final code
    if (DayCode == 0) {
        cout << Month << " " << Day << ", " << Year << " was a " << "Sunday!" << endl;
    }
    else if (DayCode == 1 || DayCode == -6){
        cout << Month << " " << Day << ", " << Year << " was a " << "Monday!" << endl;
    }
    else if (DayCode == 2 || DayCode == -5){
        cout << Month << " " << Day << ", " << Year << " was a " << "Tuesday!" << endl;
    }
    else if (DayCode == 3 || DayCode == -4){
        cout << Month << " " << Day << ", " << Year << " was a " << "Wednesday!" << endl;
    }
    else if (DayCode == 4 || DayCode == -3){
        cout << Month << " " << Day << ", " << Year << " was a " << "Thursday!" << endl;
    }
    else if (DayCode == 5 || DayCode == -2){
        cout << Month << " " << Day << ", " << Year << " was a " << "Friday!" << endl;
    }
    else if (DayCode == 6 || DayCode == -1){
        cout << Month << " " << Day << ", " << Year << " was a " << "Saturday!" << endl;
    }
    return (0);
}




