// Wenchen Shi
// UID: 505453951
//  PlaneFlight.hpp
//  Project5
//  Created by Victor Shi on 2/20/21.
//
#ifndef PlaneFlight_hpp
#define PlaneFlight_hpp
#include <string>
using namespace std;
//#include <stdio.h>

class PlaneFlight
{
private:
    double mCost;
    double mMileage;
    string mFromCity;
    string mToCity;
    string mName;
public:
    PlaneFlight(string passengerName,string fromCity, string toCity, double cost, double mileage);
    double getCost();
    void setCost( double cost);
    double getMileage();
    void setMileage (double mileage);
    string getName();
    void setName (string name);
    string getFromCity();
    void setFromCity(string from);
    string getToCity();
    void setToCity(string to);
};
#endif /* PlaneFlight_hpp */
