// Wenchen Shi
// UID: 505453951
//  PlaneFlight.cpp
//  Project5
//  Created by Victor Shi on 2/20/21.
//

#include "PlaneFlight.h"


PlaneFlight::PlaneFlight (string passengerName,string fromCity, string toCity, double cost, double mileage)
{
    //Check cost and mileage smaller than 0
    if (cost < 0)
        mCost = -1;
    else
        mCost = cost;
    if (mileage < 0)
        mMileage = -1;
    else
        mMileage = mileage;
    // name can't be empty string
    if (passengerName != "")
        mName = passengerName;
    // If the "to" and "from" parameters for the function ".freeFlight( ... )" are invalid (i.e. they are the same, or they are the empty string), do we return "false"? Or does what we return still just depend on whether the balance is sufficiently large to create a free flight for the provided mileage?
    // toCity cannot = from city
    if (toCity != fromCity)
    {
        if (fromCity != "" )
            mFromCity = fromCity;
        if (toCity != "" )
            mToCity = toCity;
    }
}

double PlaneFlight::getCost()
{
    return mCost;
}

void PlaneFlight::setCost( double cost)
{
    // cost has to be >= 0
    if (cost < 0)
        mCost = -1;
    else
        mCost = cost;
}

double PlaneFlight::getMileage()
{
    return mMileage;
}

void PlaneFlight::setMileage(double mileage)
{
    // mileage has to be >= 0
    if (mileage < 0)
        mMileage = -1;
    else
        mMileage = mileage;
}

string PlaneFlight::getName()
{
    return mName;
}

void PlaneFlight::setName(string name)
{
    // name can't be empty string
    if (name != "")
        mName = name;
}

string PlaneFlight::getFromCity()
{
    return mFromCity;
}

void PlaneFlight::setFromCity(string from)
{
    // from can't = to and from can't = empty string
    if (from != "" && from != mToCity)
        mFromCity = from;
}

string PlaneFlight::getToCity()
{
    return mToCity;
}

void PlaneFlight::setToCity(string to)
{
    //to can't = from and to can't = empty string
    if (to != "" && to != mFromCity)
        mToCity = to;
}

