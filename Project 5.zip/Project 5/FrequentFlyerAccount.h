// Wenchen Shi
// UID: 505453951
//  FrequentFlyerAccount.hpp
//  Project5
//  Created by Victor Shi on 2/20/21.
//
#ifndef FrequentFlyerAccount_hpp
#define FrequentFlyerAccount_hpp
#include <string>
#include "PlaneFlight.h"
using namespace std;

class FrequentFlyerAccount
{
    // public/private
private:
    string mName;
    double mBalance;
    // public/private
public:
    FrequentFlyerAccount (string name);
    double getBalance();
    string getName();
    bool addFlightToAccount (PlaneFlight flight);
    bool canEarnFreeFlight (double mileage);
    bool freeFlight(string from, string to, double milage, PlaneFlight & flight);
};

#endif /* FrequentFlyerAccount_hpp */
