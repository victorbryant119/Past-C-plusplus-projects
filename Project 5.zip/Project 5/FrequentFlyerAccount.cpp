// Wenchen Shi
// UID: 505453951
//  FrequentFlyerAccount.cpp
//  Project5
//  Created by Victor Shi on 2/20/21.
#include "FrequentFlyerAccount.h"
#include "PlaneFlight.h"
FrequentFlyerAccount::FrequentFlyerAccount (string name)
{
    if (name != "")
        mName = name;
    mBalance = 0;
}

double FrequentFlyerAccount::getBalance()
{
    return mBalance;
}

string FrequentFlyerAccount::getName()
{
    return mName;
}

bool FrequentFlyerAccount::addFlightToAccount(PlaneFlight flight)
{
    // how to do mileage balance
//    if (mBalance == )
        
    if (mName == flight.getName())
    {
        if (flight.getCost()>0)
        {
            // incrementation of addflighttoaccount
        mBalance = mBalance + flight.getMileage();
//        mBalance -= flight.getMileage();
//        mBalance = 0;
        return true;
        }
        else
        {
            return false;
        }
    }
    else
    {
       // mBalance = 0;
        //flight.setMileage(0);
        return false;
    }
}

bool FrequentFlyerAccount::canEarnFreeFlight (double mileage)
{
    if (mBalance >= mileage && mileage > 0)
        return true;
    else
        return false;
}

 bool FrequentFlyerAccount::freeFlight (string from, string to, double mileage,PlaneFlight & flight)
{
    // Set it up for the assertion
//    flight.setName("Howard") ;
//    flight.setFromCity("LAS");
//    flight.setToCity("LAX");
//    flight.setMileage(285.000000);
    // dummy value prevention
    PlaneFlight temp (getName(),"temp","temp", 1, 1);
//    if (canEarnFreeFlight(mileage))
    if (mBalance >= mileage)
    {
//        if (flight.getCost()!=0)
//        {
//        PlaneFlight temp (flight.getName(),flight.getFromCity(),"temp", 1, 1);
        //pass by reference
        temp.setFromCity(from);
        temp.setToCity(to);
//        temp.setName(flight.getName());
        temp.setMileage(mileage);
        temp.setCost(0);
//        mBalance = 0;
        mBalance -= mileage;
//        mBalance = mBalance + flight.getMileage();
//        PlaneFlight f( flight.getName(),from, to, 0, 0);
        // Check that after pass by reference to != from and to and from != empty string
        if (from != "" && to != "" && from != to && flight.getName()!= "")
        {
        flight = temp;
        return true;
        }
//        }
    }
    return false;

//    if (mBalance >= mileage) {
//       // PlaneFlight temp(flight.getName(), from, to, 0,  mileage);
//        flight.setToCity(to);
//        flight.setFromCity(from);
//        flight.setCost(0);
//        flight.setMileage(mileage);
//        mBalance -= mileage;
//        return true;
//    }
//    return false;
    
//    return false;
}
