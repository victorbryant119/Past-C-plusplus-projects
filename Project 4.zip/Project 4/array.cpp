// Project 4
// Wenchen Shi
// UID: 505453951
//
//
#include <iostream>
#include <string>
#include <cmath>
#include <cctype>
#include <cassert>
using namespace std;
int locateMaximum( const  string  array[ ],  int  n )
{
    if (n<=0)
        return -1;
    int Max = 0;
    // for loops to compare all strings
    for (int k = 0; k < n; k++)
    {
        if (array[k] > array[k+1] && k+1 < n)
        {
            // when k = 0
            if (k == 0)
            {
                Max = k;
            cerr << "max1: " << Max <<  endl;
            }
            // wants bigger string to become Max
            else if (array[k] > array[Max])
            {
                Max = k;
            cerr << "max2: " << Max <<  endl;
            }
        }
        else if (array[k] < array[k+1] && k+1 < n)
        {
            // when k = 0
            if (k == 0)
            {
                Max = k+1;
            cerr << "max3: " << Max <<  endl;
            }
            // wants bigger string to become Max
            else if (array[k+1] > array[Max] )
            {
                Max = k+1;
                cerr << "max4: " << Max <<  endl;
            }
        }
        // choose the smaller index if both are equal
        else if (array[k] == array[k+1])
            Max = k;
    }
    return Max;
}
//bool IsDouble(const string& s)
//{
//  istringstream i = s;
//  double temp;
//  return ( (i >> temp) ? true : false );
//}
//bool IsDouble(const string& s, double& rDouble)
//{
//  istringstream i(s);
//  if (i >> rDouble)
//  {
//    return true;
//  }
//  rDouble = 0.0;
//  return false;
//}
int countFloatingPointValues (const string array[], int n)
{
    if (n <= 0)
        return -1;
    int floating = 0;
    // for loops through all strings
    for (int k = 0; k < n; k++)
    {
        string value = array[k];
        int numOfPeriod = 0;
        // Check if the string contains a floating point value
        bool isFloat = true;
        if (value.length()==0)
        {
            isFloat = false;
        }
        // loop to find '.' for floating pt
        for (int j = 0; j < value.length(); j++)
        {
            char point = value.at(j);
            if (point == '.')
            {
                numOfPeriod++;
            }
            if (point != '.' && ! isdigit(point))
            {
                isFloat = false;
            }
        }
        // check if only one '.' in each string
        if (isFloat && numOfPeriod < 2)
        {
            floating++;
        }
    }
    return floating;
}
//int countFloatingPointValues( const string array[ ], int  n )
//{
//    int floating = 0;
//    if (n<=0)
//        return -1;
//    for (int k = 0; k < n; k++)
//    {
//        int j = 0;
//        string value = array[k];
//        bool isFloating = true;
//        if (value.length()==0)
//            isFloating = false;
//        for (int i=0; i < value.length(); i++)
//        {
//        char point = value.at(i);
//        if (point == '.')
//            j++;
//        if (point != '.' && ! isdigit(point))
//            isFloating = false;
//        }
//    if (isFloating==true && j == 1 )
//        floating++;
//    }
//    return floating;
//}


bool hasNoCapitals( const string array[ ], int n )
{
    if (n <= 0)
        return true;
    for (int k = 0; k < n; k++)
    {
        string Cap = array[k];
        for (int a = 0; a < Cap.size(); a++)
        {
            // if it falls in between 65 and 90, CAP
            if (Cap[a] >= 65 && Cap[a] <= 90)
                return false;
        }
    }
    return true;
}

bool identicalValuesTogether( const string array[ ], int n)
{
    bool identical = true;
    if (n <= 0)
        return false;
    for (int k = 0; k < n; k++)
    {
        string Cap = array[k];
        for (int j = 1; j < n-k; j++)
        {
        // if identical values are not together, false
            if (array[k]==array[k+j] && j!=1)
            {
            if (array[k+j-1]!=array[k])
                return identical = false;
            }
        }
    }
    return identical;
}

bool hasTwoOrMoreDuplicates( const string array[ ], int  n )
{
    bool Duplicate = true;
    int count = 0;
    if (n <= 0)
        return Duplicate = false;
    for (int k = 0; k < n; k++)
    {
        string Duplicates = array[k];
        // count up if there are duplicates
        for (int j = 1; j < n-k; j++)
        {
            if (array[k]==array[k+j])
                count++;
        }
    }
    if (count >= 2)
        return Duplicate = true;
    else
        return Duplicate = false;
}
int shiftLeft( string array[ ], int n, int amount, string placeholder )
{
    if ( n<=0 || amount < 0)
        return -1;
    for (int k = 0; k < n; k++)
    {
//            if (k-amount>=0)
//            {
                string rightmost = array[k];
//                if (rightmost.size()-k+1 <= amount)
//                if (k < rightmost.size()-1-amount)
//                {
//                    array[k] = array[k+amount];
//                    cerr << array[k] << endl;
//                }
                // n = max index - 1
                // when k = n-amount, the first to have placeholder
                if (k > n-1-amount)
                {
                    array[k] = placeholder;
                    cerr << array[k] << endl;
                }
                else
                {
                    array[k] = array[k+amount];
                    cerr << array[k] << endl;
                }
//            }
    }
    if (amount > n)
        return n;
    return amount;
}
int replaceFirstAndLastOccurrences( string array[ ], int n, char charToFind, char charToReplace )
{
    if (n <= 0)
        return -1;
    int count = 0;
    int lastCountPos = -1;
    string Occur;
    // replace charToFind with charToReplace
    for (int k = 0; k < n; k++)
    {
        Occur = array[k];
        int reset = 0;
        lastCountPos = -1;
        // loop inside the strings
        for (int j = 0; j < Occur.size(); j++)
        {
            if (Occur[j] == charToFind)
            {
                // AAAAAAAB
                // keep track of the 'A' position
                lastCountPos = j;
            // Eliminate other occurrences (non first and last)
                if ( reset == 0)
                {
                    Occur[j] = charToReplace;
                    count ++;
                }
                else if (j == Occur.size() - 1 ){
                  Occur[j] = charToReplace;
                    count ++;
                }
                //
            }
            else if (j == Occur.size()-1)
            {
                if(lastCountPos != -1)
                {
                  Occur[lastCountPos] = charToReplace;
                  count++;
                }
            }
//             Check individual character
//            cerr << Occur[j] << endl;
            reset++;
        }
        array[k] = Occur;
        cerr << array[k] << endl;
        
    }
    return count;
}
// Return the position of the first element that is not <= the one
    // that follows it.  Return −1 if there are no such elements.
//        int findFirstDisorder(const string a[], int n)
//        {
//            for (int k = 0; k < n-1; k++)
//            if (a[k+1] > a[k])
//            return k;
//            return -1;
//        }

        int main()
        {
            //Check locateMaximum, countFloatingPointValues, hasNoCapitals, and identicalValuesTogether
            string array[8]={"able", "4.2", "Gat", "bog", "Game", "wenchen","cake", "wenchen"};
            assert(locateMaximum(array, 8) == 5);
            assert(countFloatingPointValues(array, 6) == 1);
            assert(countFloatingPointValues(array, 2) == 1);
            assert(hasNoCapitals(array, 4)== false);
            assert(hasNoCapitals(array, 6)== false);
            assert(identicalValuesTogether(array, 8)==false);
            //Check identicalValuesTogether and hasTwoOrMoreDuplicates
//            string array[9]={"able", "4.2", "Gat", "bog", "Game", "wenchen","wenchen", "cake", "wenchen"};
//            assert(identicalValuesTogether(array, 9) == false);
//            assert(hasTwoOrMoreDuplicates(array, 9)== true);
//            string array[7] = {"AA", "BB", "aa", "bb", "cc", "dd", "ee" };
//            assert(locateMaximum(array, 7)==6);
            //Check floating
//            string array[7]={"55.", "4A", "35", "55.", "15.0", "15.0", "A12A"};
//            assert(countFloatingPointValues(array, 7)==5);
//            string array[4] ={ "A", "+000.75", "1,000,000..", "-12.345"};
//            assert(countFloatingPointValues(array, 4)==0);
//            string array[4] = {"A", "000.75", "1000000", "12.345"};
//            assert(countFloatingPointValues(array, 4)==3);
//            string array[4] = {".", "000.75", "1000000", "12.345"};
//            assert(countFloatingPointValues(array, 4)==4);
            // Check locateMaximum
//            string array[4]={"A", "Basdfads", "Casddasdf", "Casddasdf"};
//            assert(locateMaximum(array, 4)==2);
//            string array[4] = {"A", "Basdadsf", "C", "B"};
//            assert(locateMaximum(array, -4040)==-1);
//            string array[4] = {"A", "Basdadsf", "C", "B"};
//            assert(locateMaximum(array, 0)==-1);
//            string array[4]={"Table", "Tbt", "Tdat", "Tcog"};
//            assert(locateMaximum(array, 4)== 2);
            //Check hasNoCapitals
//            string array[4] = {"A", "B", "C", "B"};
//            assert(hasNoCapitals(array, 4)==false);
//            string array [4] = {"a", "b", "c", "d"};
//            assert(hasNoCapitals(array, 4)==true);
//            string array [4] = {"a", "2.234", "24523", "d"};
//            assert(hasNoCapitals(array, 4)==true);
//            string array[4] = {"A", "B", "C", "B"};
//            assert(hasNoCapitals(array, -234)==true);
            // Check identicalValuesTogether
//            string array [7] = {"AA", "BB", "BB", "BB", "cc", "dd", "ee"};
//            assert(identicalValuesTogether(array, 5)==true);
//            string array[5] = {"a", "a", "b", "c", "b"};
//            assert(identicalValuesTogether(array, 5)==false);
//            string array[5] = {"a", "b", "c", "d", "e"};
//            assert(identicalValuesTogether(array, 5)==true);
//            string array[5] = {"a", "a", "b", "a", "a"};
//            assert(identicalValuesTogether(array, 5)==false);
//            string array[5] = {"a", "a", "a", "b", "c"};
//            assert(identicalValuesTogether(array, 5)==true);
            // Check hasTwoOrMoreDuplicates
//            string array[5] = {"a", "b", "a", "b", "a"};
//            assert(hasTwoOrMoreDuplicates(array, 5)==true);
//            string array [5] = {"a", "a", "a", "a", "b"};
//            assert(hasTwoOrMoreDuplicates(array, 5)==true);
//            string array [5] = {"a", "a", "a", "a", "a"};
//            assert(hasTwoOrMoreDuplicates(array, 5)==true);
            // Shiftleft
//            string array [5] = {"a", "a", "a", "c", "b"};
//            assert(shiftLeft(array, 5, 2, "foo")==5);
//            string array [5] = {"a", "a", "foo", "c", "b"};
//            assert(shiftLeft(array, 5 ,1, "foo")==1);
//            string array [5] = { "a", "a", "a", "c", "b"};
//            assert(shiftLeft(array, 5, 20, "foo")==5);
//            string array [4] = { "a", "b", "c", "b"};
//            assert(shiftLeft(array, 4, 0, "foo")==0);
//            string array [10] = { "she", "him", "I", "love", "you", "more", "than", "majiao", "loves", "me"};
//            assert(shiftLeft(array, 10, 2, "love")== 2);
            // replaceFirstAndLastOccurrences
//            string folks[8] = {  "samwell", "jon", "margaery", "daenerys",
//                                      "tyrion", "sansa", "magdalena", "jon" };
//            assert(replaceFirstAndLastOccurrences( folks, 8, 'A', 'Z' )==0);
//            string array[4] = {"AAA", "ABA", "ACAAA", "zzzzzA"};
//            assert(replaceFirstAndLastOccurrences(array, 4, 'A', 'z')==7);
//            string array[7] = {"AA", "BB", "aa", "bb", "cc", "dd", "ee"};
//            assert(replaceFirstAndLastOccurrences(array, 6, 'A', 'z')==2);
            // There should be another test that passes a bad argument
            cout << "All tests succeeded" << endl;
        }
