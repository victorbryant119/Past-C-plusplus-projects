// Wenchen Shi
// UID: 505453951
//  Board.cpp
//  BeatThat
//

#include "Board.h"


namespace cs31
{
    // setup a new Board
    Board::Board() : mGameOver(false), mHumanWon(false), mComputerWon(false), mHumanRoundsWon(0), mComputerRoundsWon(0), mHumanDie1(), mHumanDie2(), mComputerDie1(), mComputerDie2(), mTurnsLeft(0)
    {
        
    }

    // adjust mHumanWon, mComputerWon and mGameOver appropriately
    void Board::markTied()
    {
//        if (isGameOver()&&getHumanRoundsWon()==getComputerRoundsWon())
//            mGameOver = true;
// Conditions not set here
        mHumanWon = false;
        mComputerWon = false;
        mGameOver = true;
    }
    
    // adjust mHumanWon, mComputerWon and mGameOver appropriately
    //if statement
    void Board::markHumanAsWinner()
    {
//        if (isGameOver()&&getHumanRoundsWon()>getComputerRoundsWon())
//        {
//        mHumanWon = true;
//        mGameOver = true;
//        }
        // Conditions not set here
        mHumanWon = true;
        mComputerWon = false;
        mGameOver = true;
    }
    
    // adjust mHumanWon, mComputerWon and mGameOver appropriately
    void Board::markComputerAsWinner()
    {
//        if (isGameOver()&&getHumanRoundsWon()<getComputerRoundsWon())
//        {
        // Conditions not set here
        mHumanWon = false;
        mComputerWon = true;
        mGameOver = true;
//        }
    }
    
    bool Board::isGameOver( ) const
    {
        // Conditions not set here
        if (mGameOver)
            return( true );
        else
            return false;
    }

    bool Board::didHumanWin() const
    {
//        if (mHumanWon&&isGameOver())
//            return true;
        // Check conditions if human won more rounds than computer
        if (mHumanRoundsWon > mComputerWon && isGameOver()&& mHumanWon)
            return true;
        return( false );
    }
    
    bool Board::didComputerWin() const
    {
        // Check conditions if human won fewer rounds than computer
        if (mComputerRoundsWon > mHumanRoundsWon&&isGameOver()&& mComputerWon)
            return true;
        return( false );
    }

    // trivial setters

    void Board::setTurnsLeft( int turns )
    {
        mTurnsLeft = turns;
    }

    void Board::setHumanRoundsWon( int rounds )
    {
        mHumanRoundsWon = rounds;
    }

    void Board::setComputerRoundsWon( int rounds )
    {
        mComputerRoundsWon = rounds;
    }

    void Board::setHumanDiceRolled( Die d1, Die d2 )
    {
        mHumanDie1 = d1;
        mHumanDie2 = d2;
    }

    void Board::setComputerDiceRolled( Die d1, Die d2 )
    {
        mComputerDie1 = d1;
        mComputerDie2 = d2;
    }

    // trivial getters

    int Board::getHumanRoundsWon( )
    {
        return( mHumanRoundsWon );
    }

    int Board::getComputerRoundsWon( )
    {
        return( mComputerRoundsWon );
    }

    int Board::getTurnsLeft( )
    {
        return( mTurnsLeft );
    }

    // major method called with each round of play by the BeatThat class
    std::string Board::display( std::string message ) const
    {
        std::string s = "\n\n\t--BeatThat Game--\n";
        
        s += "\n";
        s += "\t\t";
        s += "human rolled:";
        s += std::to_string( mHumanDie1.getValue() );
        s += std::to_string( mHumanDie2.getValue() );
        s += "\n";
        s += "\t\t";
        s += "computer rolled:";
        s += std::to_string( mComputerDie1.getValue() );
        s += std::to_string( mComputerDie2.getValue() );
        s += "\n";
        s += "\n";
        s += message;
        s += "\n\n";
        s += "Human \t\trounds won:";
        s += std::to_string( mHumanRoundsWon );
        s += "\t\tTurns Left ";
        s += std::to_string( mTurnsLeft );
        s += "\n";
        s += "Computer \trounds won:";
        s += std::to_string( mComputerRoundsWon );
        s += "\n\n\n";
        return( s );
    }

    std::string Board::endingMessage() const
    {
        std::string s( "" );
        if (isGameOver() && didHumanWin())
        {
            s = "\n\t\tyou won BeatThat!\n";
        }
        else if (isGameOver() && didComputerWin())
        {
            s = "\n\t\tyou lost BeatThat!\n";
        }
        else if (isGameOver() && (!didComputerWin() && !didHumanWin()))
        {
            s = "\n\t\tBeatThat ended in a tied game!\n";
        }
        return( s );
    }
    


    
}


