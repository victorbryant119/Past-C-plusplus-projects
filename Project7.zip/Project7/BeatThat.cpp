// Wenchen Shi
// UID: 505453951
//  BeatThat.cpp
//  BeatThat
//

#include "BeatThat.h"
#include <iostream>
using namespace std;

namespace cs31
{
    // human goes first
    BeatThat::BeatThat() : mHuman(), mComputer(), mBoard(), mTurnCount(0), mBoardMessage( "" )
    {
        
    }

    void BeatThat::humanPlay()
    {
        mHuman.roll();
    }
    
    void BeatThat::humanPlay( Die d1, Die d2 )
    {
//        d1.roll();
//        d2.roll();
        // don't roll but assignment
        //Cheating way
        mHuman.roll(d1, d2);
    }

    void BeatThat::computerPlay( )
    {
        mComputer.roll();
    }

    void BeatThat::computerPlay( Die d1, Die d2 )
    {
//        d1.roll();
//        d2.roll();
        // don't roll but assignment
        //Cheating way
        mComputer.roll(d1,d2);
    }
        
    // should properly return either: GAMEOUTCOME::GAMENOTOVER,
    //                                GAMEOUTCOME::HUMANWONGAME,
    //                                GAMEOUTCOME::COMPUTERWONGAME or
    //                                GAMEOUTCOME::TIEDGAME
    BeatThat::GAMEOUTCOME  BeatThat::determineGameOutcome( ) const
    {
        // just to get the skeleton to build...
        // wrong to use isGameover since it called determineGameoutcome
        // compare roundswon and check turnsleft
        if (mTurnCount == 5)
        {
            if (mHuman.getRoundsWon()<mComputer.getRoundsWon()&&turnsLeft()==0)
            {
//            if (mBoard.didComputerWin())
//            {
                GAMEOUTCOME result = GAMEOUTCOME::COMPUTERWONGAME;
                return( result );
            }
            else if (mHuman.getRoundsWon()>mComputer.getRoundsWon()&&turnsLeft()==0)
//            else if (mBoard.didHumanWin())
            {
                GAMEOUTCOME result = GAMEOUTCOME::HUMANWONGAME;
                return( result );
            }
//            else if (mHuman.getRoundsWon()==mComputer.getRoundsWon()&&!mBoard.didComputerWin()&&mBoard.isGameOver()&&turnsLeft()==0)
            else 
            {
                GAMEOUTCOME result = GAMEOUTCOME::TIEDGAME;
                return( result );
            }
        }
        else
            {
                GAMEOUTCOME result = GAMEOUTCOME::GAMENOTOVER;
                return( result );
            }
    }
    
    bool BeatThat::isGameOver()
    {
        GAMEOUTCOME result = determineGameOutcome();
        if (result != GAMEOUTCOME::GAMENOTOVER)
        {
            if (result == GAMEOUTCOME::HUMANWONGAME)
            {
                mBoard.markHumanAsWinner();
            }
            else if (result == GAMEOUTCOME::COMPUTERWONGAME)
            {
                mBoard.markComputerAsWinner();
            }
            else
            {
                mBoard.markTied();
            }
        }
        return( result != GAMEOUTCOME::GAMENOTOVER );
    }

    // trivial getters
    Player BeatThat::getHuman() const
    {
        return( mHuman );
    }
    
    Player BeatThat::getComputer() const
    {
        return( mComputer );
    }
    
    Board  BeatThat::getBoard() const
    {
        return( mBoard );
    }

    // game output messages including the board message
    std::string BeatThat::display( std::string msg )
    {
       using namespace std;
       std::string s( "" );
    
        s = mBoard.display( mBoardMessage );
        if (!isGameOver())
        {
            s = s + msg;
        }

        return( s );
    }

    std::string BeatThat::endingMessage() const
    {
        return( mBoard.endingMessage() );
    }

    // review the roll dice and determine who won this round or it ended tied
    void BeatThat::evaluateRolls( )
    {
        int humanLargestNumber = mHuman.largestDie( ).getValue();
        int computerLargestNumber = mComputer.largestDie().getValue();
 
        int humanSmallestNumber = mHuman.smallestDie( ).getValue();
        int computerSmallestNumber = mComputer.smallestDie().getValue();
        
        if (humanLargestNumber > computerLargestNumber)
        {
            // human won this turn...
            mHuman.wonARound();
            mBoardMessage = HUMAN_WON_TURN;
        }
        else if (computerLargestNumber > humanLargestNumber)
        {
            // computer won this turn...
            mComputer.wonARound();
            mBoardMessage = COMPUTER_WON_TURN;
        }
        else
        {
            // largest dies were equal so move onto the smallest dies
            if (humanSmallestNumber > computerSmallestNumber)
            {
                // humaan won this turn...
                mHuman.wonARound();
                mBoardMessage = HUMAN_WON_TURN;
            }
            else if (computerSmallestNumber > humanSmallestNumber)
            {
                // computer won this turn...
                mComputer.wonARound();
                mBoardMessage = COMPUTER_WON_TURN;
            }
            else
            {
                mBoardMessage = NO_ONE_WON_TURN;
            }
        }
    }

    int BeatThat::turnsLeft() const
    {
        return( MAX_NUMBER_OF_TURNS - mTurnCount );
    }

    // update the board for the latest round of play
    void BeatThat::updateBoard( )
    {
        mBoard.setComputerRoundsWon( mComputer.getRoundsWon() );
        mBoard.setHumanRoundsWon( mHuman.getRoundsWon() );
        mBoard.setHumanDiceRolled(mHuman.getDie1(), mHuman.getDie2());
        mBoard.setComputerDiceRolled(mComputer.getDie1(), mComputer.getDie2());
        mBoard.setTurnsLeft(turnsLeft());
    }

    // called to indicate a turn has ended
    // increment the turn counter
    // evaluate the rolled dice
    // update the board for the latest round of play
    void BeatThat::endTurn( )
    {
        mTurnCount += 1;
        evaluateRolls( );
        updateBoard( );
    }

}

